<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <title>忘記密碼?</title>
        <script src="../JS/login_script.js"> </script>
        
    </head>

    <link rel="stylesheet" type="text/css" href="../style.css">

    <body>

        <div style = "text-align:center";>

            <h1>忘記密碼</h1><br>
            <h2>請輸入電子郵件</h2><br>

            <form action="" method="post">
                <input type="email"; id=email; name=email; style="font-size:25px; padding:10px;" size="30"; placeholder="example@gmail.com"/><br><br>

                <input type="button"; name=send; style="font-size:25px; width:200px; height:50px;" value="送出";  onclick=""/><br><br>

                <hr>

            </form>

        </div>
    </body>

</html>

